import numpy as np
import matplotlib.pyplot as plt

# Load the data from the file
data = np.loadtxt("avgsd_ep_s10_g501_r2o5.data")

# Extract the values for plotting
bandwidth = data[:, 0]
average = data[:, 1]
stddev = data[:, 2]

# Add a horizontal baseline at y = 500
plt.axhline(y=500, color='gray', linestyle='--', label='Baseline at 500')

# Plotting the averages with error bars
plt.errorbar(bandwidth, average, yerr=stddev, fmt='o')
plt.xlabel('Bandwidth')
plt.ylabel('Average')
plt.title('EntropicDoubleWellPotential,Scaling10')

# Add text to specify labeling
plt.text(0.95, 0.9, 'range:-2.5:2.5,grid:501', horizontalalignment='right', transform=plt.gca().transAxes, bbox=dict(facecolor='white', alpha=0.5))


# Save the figure
plt.savefig('avgsd_ep_s10_g501_r2o5.png')

# Show the plot
plt.show()

