import numpy as np
import matplotlib.pyplot as plt

# List of data files
data_files = ["particle_dist_b0.data","particle_dist_bo1.data","particle_dist_bo2.data","particle_dist_bo3.data"]

# List of bandwidth values
bandwidths = [0, 0.1, 0.2,  0.3 ]

# Initialize an empty list to store the data
all_data = []

# Load and append data from each file
for file in data_files:
    data = np.loadtxt(file, skiprows=3)
    all_data.append(data)

# Plotting the number of particles for each bandwidth
for i, data in enumerate(all_data):
    time = data[:, 0] # Extract time values
    n_particles_0 = data[:, 1] # Extract n_particles_0 values
    bandwidth = bandwidths[i]
    label = f"σ = {bandwidth}"  # Using Greek letter sigma

    # Filter data within the desired time range
    mask = (time >= 0) & (time <= 50000)
    time = time[mask]
    n_particles_0 = n_particles_0[mask]

    plt.plot(time, n_particles_0, label=label)

# Set plot labels and title
plt.xlabel('Time [$\delta t$]')
plt.ylabel('$N_L/N$')
#plt.title('Number of Particles vs Time')
plt.legend()

# Add padding between title and plot
plt.tight_layout()

# Save the figure
plt.savefig('time_vs_np.png')

