
workdir=./

virt_env_dir="/data/bee8/gopakumara/epgridrange_1e1"

source $virt_env_dir/.venv/bin/activate

cd $workdir
/data/bee8/gopakumara/epgridrange_1e1/.venv/bin/python -m  bdld input

